package com.example.kuis_124240072

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
