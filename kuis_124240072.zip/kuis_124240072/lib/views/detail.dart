import 'package:flutter/material.dart';
import '../models/data.dart';

class DetailPage extends StatefulWidget {
  final Product catalog; // 'Product' dari model, 'catalog' bebas nama variabelnya

  const DetailPage({super.key, required this.catalog});

  @override
  State<DetailPage> createState() => _DetailPageState();
}

class _DetailPageState extends State<DetailPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.catalog.productName),
        actions: [
          // Tombol Favorit 
          IconButton(
            icon: Icon(
              widget.catalog.isFavorite ? Icons.favorite : Icons.favorite_border,
              color: widget.catalog.isFavorite ? Colors.red : const Color(0xFF65558F),
            ),
            onPressed: () {
              setState(() {
                widget.catalog.isFavorite = !widget.catalog.isFavorite;
              });
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Gambar Catalog
            ClipRRect(
              borderRadius: BorderRadius.circular(12.0),
              child: Image.network(
                widget.catalog.imageUrl,
                width: double.infinity,
                height: 300,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  height: 300,
                  color: Colors.grey[300],
                  child: const Icon(Icons.fastfood, size: 80),
                ),
              ),
            ),
            const SizedBox(height: 16),
            // Nama Catalog
            Text(
              widget.catalog.productName,
              style: const TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
            // Kategori Catalog
            Text(
              widget.catalog.type,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 12),
            // Harga Catalog
            Text(
              widget.catalog.price,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 16),
            // Jumlah produk
            Text(
              'Jumlah Produk',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 7),
            // jumlah likes
            Text(
            'Likes:',
              style: const TextStyle(
                fontSize: 14,
                color: Color.fromARGB(255, 58, 58, 58),
              ),
            ),
            
            Text(
              widget.catalog.likeCount.toString() + ' Likes', 
              style: const TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),

            Text(
            'Stok Produk:',
              style: const TextStyle(
                fontSize: 14,
                color: Color.fromARGB(255, 58, 58, 58),
              ),
            ),

            Text(
              widget.catalog.stock.toString(), 
              style: const TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 16),

            const Text(
              'Ukuran',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              widget.catalog.sizes.join(', '), 
              style: const TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 16),

            // Deskripsi catalog
            const Text(
              'Deskripsi',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              widget.catalog.details,
              style: const TextStyle(fontSize: 14, height: 1.4),
            ),
          ],
        ),
      ),
    );
  }
}