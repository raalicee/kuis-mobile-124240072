import 'package:flutter/material.dart';
import '../models/data.dart';
import 'detail.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _searchQuery = '';
  bool _showOnlyFavorites = false;

  @override
  Widget build(BuildContext context) {
    // Filter berdasarkan pencarian dan status favorit
    final filteredCatalog = catalog.where((catalog) { 
      final matchesSearch =
          catalog.productName.toLowerCase().contains(_searchQuery.toLowerCase());
      final matchesFavorite = _showOnlyFavorites ? catalog.isFavorite : true;
      return matchesSearch && matchesFavorite;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
        automaticallyImplyLeading: false,
        actions: [
          // Tombol Filter Favorit 
          IconButton(
            icon: Icon(
              _showOnlyFavorites ? Icons.favorite : Icons.favorite_border,
              color: _showOnlyFavorites ? Colors.red : const Color(0xFF65558F),
            ),
            tooltip: _showOnlyFavorites ? 'Tampilkan Semua' : 'Tampilkan Favorit',
            onPressed: () {
              setState(() {
                _showOnlyFavorites = !_showOnlyFavorites;
              });
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Input Search
          Padding(
            padding: const EdgeInsets.all(12.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Cari produk...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
              onChanged: (val) {
                setState(() {
                  _searchQuery = val;
                });
              },
            ),
          ),
          // List Catalog
          Expanded(
            child: filteredCatalog.isEmpty
                ? const Center(child: Text('Tidak ada Catalog ditemukan.'))
                : ListView.builder(
                    itemCount: filteredCatalog.length,
                    itemBuilder: (context, index) {
                      final catalog = filteredCatalog[index];
                      return ListTile(
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(8.0),
                          child: Image.network(
                            catalog.imageUrl,
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                const Icon(Icons.fastfood, size: 50),
                          ),
                        ),
                        title: Text(
                          catalog.productName,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: 
                        Text(catalog.price),
                        
                        trailing: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(catalog.likeCount.toString() + ' Likes'),
                            Text(
                              'Stok: ${catalog.stock}',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Color.fromARGB(255, 117, 105, 105),
                              ),
                            ),
                          ],
                        ),
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => DetailPage(catalog: catalog),
                            ),
                          );
                          setState(() {}); 
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}